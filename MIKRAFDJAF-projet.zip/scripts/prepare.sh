#!/usr/bin/env bash
# Prépare les éléments téléchargés au moment de la fabrication :
#  - le moteur PHP statique pour Android 64 bits (jniLibs/<abi>/libphp.so)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$(mktemp -d)"
JNI="$ROOT/app/src/main/jniLibs"
mkdir -p "$JNI"

echo "==> Téléchargement du moteur PHP"
sudo apt-get install -y -qq upx-ucl >/dev/null 2>&1 || true
BASE="https://dl.static-php.dev/static-php-cli/common"
LIST="$(curl -fsSL "$BASE/")"
for pair in "aarch64:arm64-v8a" "x86_64:x86_64"; do
  arch="${pair%%:*}"; abi="${pair##*:}"
  file=""
  for v in 8.3 8.2; do
    file="$(echo "$LIST" | grep -oE "php-${v//./\\.}\.[0-9]+-cli-linux-${arch}\.tar\.gz" | sort -uV | tail -1 || true)"
    [ -n "$file" ] && break
  done
  if [ -z "$file" ]; then
    echo "ERREUR : binaire PHP introuvable pour $arch sur $BASE" >&2
    exit 1
  fi
  echo "   $arch -> $file"
  mkdir -p "$WORK/php-$arch" "$JNI/$abi"
  curl -fsSL "$BASE/$file" | tar xz -C "$WORK/php-$arch"
  bin="$(find "$WORK/php-$arch" -type f -name php | head -1)"
  # Décompresser si le binaire est compressé avec UPX (plus fiable sur Android)
  if command -v upx >/dev/null && upx -t "$bin" >/dev/null 2>&1; then upx -q -d "$bin" >/dev/null; fi
  cp "$bin" "$JNI/$abi/libphp.so"
  chmod 755 "$JNI/$abi/libphp.so"
  file "$JNI/$abi/libphp.so" || true
done

# Vérification rapide sur la machine de fabrication (x86_64)
"$JNI/x86_64/libphp.so" -v
"$JNI/x86_64/libphp.so" -m | tr '\n' ' '; echo
echo "==> Préparation terminée"
