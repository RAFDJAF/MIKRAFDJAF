#!/usr/bin/env bash
# Vérifie le moteur PHP fourni avec le projet.
# Il s'agit de PHP 8.3 compilé spécialement pour Android (voir scripts/php-android/) :
# le PHP générique se fait arrêter par Android 16 (appel système "accept" interdit).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BIN="$ROOT/app/src/main/jniLibs/arm64-v8a/libphp.so"
if [ ! -s "$BIN" ]; then
  echo "ERREUR : moteur PHP absent ($BIN). Renvoyez le fichier MIKRAFDJAF-projet.zip complet." >&2
  exit 1
fi
file "$BIN" || true
ls -l "$BIN"
echo "==> Moteur PHP Android présent"
