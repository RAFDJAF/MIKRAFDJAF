/* Compatibilité Android : Android interdit aux applis l'appel système accept
 * (seul accept4 est autorisé). On appelle directement l'appel système accept4.
 * Attention : accept4() de musl rappelle accept() quand flags vaut 0, d'où
 * l'appel système direct (sinon boucle infinie). */
#define _GNU_SOURCE
#include <sys/socket.h>
#include <sys/syscall.h>
#include <unistd.h>

int accept(int fd, struct sockaddr *restrict addr, socklen_t *restrict len)
{
    return (int) syscall(SYS_accept4, fd, addr, len, 0);
}
