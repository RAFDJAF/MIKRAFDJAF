#!/usr/bin/env python3
"""
Rend le binaire PHP (statique, musl, aarch64) compatible Android.

Android interdit aux applications l'appel système `accept` (n° 202 sur arm64) :
seul `accept4` (n° 242) est autorisé. Le serveur web intégré de PHP utilise
accept(), via musl, et Android le tue (signal 31 SIGSYS) à la première connexion.

musl implémente accept() ainsi :  __syscall_cp(SYS_accept, fd, addr, len, 0, 0, 0)
accept4(fd, addr, len, flags=0) a exactement le même effet. On remplace donc,
dans cette fonction seulement, le numéro 202 par 242 (le 4e argument vaut déjà 0).

Usage : patch_accept.py <binaire>   (modifie le fichier sur place)
"""
import struct, sys

MOVZ_X0_202, MOVZ_W0_202 = 0xD2801940, 0x52801940
NEW = {MOVZ_X0_202: 0xD2801E40, MOVZ_W0_202: 0x52801E40}  # même registre, valeur 242


def exec_ranges(data):
    if data[:4] != b"\x7fELF" or data[4] != 2 or data[5] != 1:
        sys.exit("ERREUR: pas un ELF 64 bits little-endian")
    machine = struct.unpack_from("<H", data, 18)[0]
    if machine != 183:
        sys.exit("ERREUR: pas un binaire aarch64 (machine=%d)" % machine)
    phoff, = struct.unpack_from("<Q", data, 32)
    phentsize, phnum = struct.unpack_from("<HH", data, 54)
    for i in range(phnum):
        p_type, p_flags, p_offset, _, _, p_filesz = struct.unpack_from("<IIQQQQ", data, phoff + i * phentsize)
        if p_type == 1 and p_flags & 1:  # PT_LOAD exécutable
            yield p_offset, p_offset + p_filesz


def is_zero_mov(w, reg):
    # movz xN/wN, #0  |  mov xN, xzr (orr xN, xzr, xzr)  |  mov wN, wzr
    return w in (0xD2800000 | reg, 0x52800000 | reg, 0xAA1F03E0 | reg, 0x2A1F03E0 | reg)


def is_bl_or_b(w):
    return (w & 0xFC000000) in (0x94000000, 0x14000000)


def main():
    path = sys.argv[1]
    data = bytearray(open(path, "rb").read())
    hits = []
    for start, end in exec_ranges(data):
        start += (-start) % 4
        for off in range(start, end - 4, 4):
            w, = struct.unpack_from("<I", data, off)
            if w not in NEW:
                continue
            lo, hi = max(start, off - 40), min(end - 4, off + 40)
            win = [struct.unpack_from("<I", data, o)[0] for o in range(lo, hi, 4)]
            zeros = sum(any(is_zero_mov(x, r) for x in win) for r in (4, 5, 6))
            calls = any(is_bl_or_b(x) for x in win[(off - lo) // 4:])
            if zeros >= 3 and calls:
                hits.append(off)
    print("emplacements accept() trouvés :", ["0x%x" % h for h in hits])
    if len(hits) != 1:
        sys.exit("ERREUR: attendu exactement 1 emplacement, trouvé %d" % len(hits))
    off = hits[0]
    w, = struct.unpack_from("<I", data, off)
    struct.pack_into("<I", data, off, NEW[w])
    open(path, "wb").write(data)
    print("OK : accept (202) remplacé par accept4 (242) à 0x%x" % off)


if __name__ == "__main__":
    main()
