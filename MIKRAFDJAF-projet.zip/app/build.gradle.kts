plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mikrafdjaf.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mikrafdjaf.app"
        minSdk = 24          // Android 7.0
        targetSdk = 34
        versionCode = (System.getenv("BUILD_NUMBER") ?: "1").toInt()
        versionName = "1.0." + (System.getenv("BUILD_NUMBER") ?: "1")
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("mikrafdjaf.keystore")
            storePassword = "mikrafdjaf"
            keyAlias = "mikrafdjaf"
            keyPassword = "mikrafdjaf"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    // Le binaire PHP est livré comme "libphp.so" : il doit être extrait
    // sur le téléphone pour pouvoir être exécuté (Android 10+).
    packaging { jniLibs { useLegacyPackaging = true } }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
}
