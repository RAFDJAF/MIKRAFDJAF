package com.mikrafdjaf.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.print.PrintManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MainActivity : Activity() {

    private lateinit var server: PhpServer
    private lateinit var sites: SiteManager
    private lateinit var webView: WebView
    private lateinit var webPanel: LinearLayout
    private lateinit var webTitle: TextView
    private lateinit var home: ScrollView
    private lateinit var homeList: LinearLayout
    private lateinit var loading: LinearLayout
    private lateinit var loadingText: TextView
    private val ui = Handler(Looper.getMainLooper())
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var lastPrint = 0L
    private var currentSite: Site? = null

    private val blue = Color.parseColor("#0E5A8A")
    private val green = Color.parseColor("#16A34A")

    // Remplace window.print() de Mikhmon par l'impression Android (tickets / rapports)
    private val printHook = """
        (function(){
          if (window.__mkPrint) return; window.__mkPrint = true;
          window.print = function(){ if (window.MIKRAFDJAF) MIKRAFDJAF.print(); };
        })();
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        server = PhpServer(applicationContext)
        sites = SiteManager(applicationContext)
        Thread { server.killStrays() }.start() // reste d'une session précédente
        buildUi()
        showHome()
    }

    // ---------------------------------------------------------------- Interface

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int, radius: Int = 12) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildUi() {
        val root = FrameLayout(this)

        // --- Écran d'accueil : liste des Mikhmon importés
        homeList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        home = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#F3F6F9"))
            addView(homeList)
        }

        // --- Écran Mikhmon : barre du haut + WebView
        webTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(blue)
            text = "◀  Mes Mikhmon"
            setOnClickListener { showHome() }
        }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.setSupportMultipleWindows(false) // les "_blank" s'ouvrent dans l'appli
            settings.javaScriptCanOpenWindowsAutomatically = true
            addJavascriptInterface(PrintBridge(), "MIKRAFDJAF")
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, printHook, setOf("*"))
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val url = req.url
                if (url.host == "127.0.0.1" || url.host == "localhost") return false
                return try { startActivity(Intent(Intent.ACTION_VIEW, url)); true } catch (e: Exception) { true }
            }

            override fun onPageFinished(view: WebView, url: String) {
                view.evaluateJavascript(printHook, null)
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT) &&
                    url.contains("/print.php")) doPrint()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    startActivityForResult(params.createIntent(), REQ_UPLOAD); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }
        webPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(webTitle, LinearLayout.LayoutParams(MATCH_PARENT, dp(44)))
            addView(webView, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }

        // --- Écran de chargement
        loadingText = TextView(this).apply {
            setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(24), 0, dp(24), 0)
        }
        loading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(blue)
            isClickable = true
            addView(TextView(context).apply {
                text = "MIKRAFDJAF"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            })
            addView(ProgressBar(context).apply { setPadding(0, dp(16), 0, dp(16)) },
                LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
            addView(loadingText)
        }

        root.addView(home, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(webPanel, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(loading, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)
    }

    private fun showLoading(msg: String?) {
        if (msg == null) loading.visibility = View.GONE
        else { loadingText.text = msg; loading.visibility = View.VISIBLE }
    }

    private fun showHome() {
        webPanel.visibility = View.GONE
        home.visibility = View.VISIBLE
        homeList.removeAllViews()

        homeList.addView(TextView(this).apply {
            text = "MIKRAFDJAF"; textSize = 26f; setTextColor(blue)
            setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER
        })
        val list = sites.list()
        homeList.addView(TextView(this).apply {
            text = if (list.isEmpty())
                "Aucun Mikhmon pour l'instant.\nImportez votre dossier Mikhmon (ou son fichier ZIP) pour commencer."
            else "Touchez le Mikhmon à ouvrir.\nAppui long : renommer ou supprimer."
            gravity = Gravity.CENTER; setTextColor(Color.DKGRAY)
            setPadding(0, dp(6), 0, dp(18))
        })

        for (site in list) {
            homeList.addView(Button(this).apply {
                text = site.name
                isAllCaps = false
                textSize = 18f
                setTextColor(Color.WHITE)
                background = roundBg(blue)
                setOnClickListener { openSite(site) }
                setOnLongClickListener { siteMenu(site); true }
            }, LinearLayout.LayoutParams(MATCH_PARENT, dp(64)).apply { bottomMargin = dp(12) })
        }

        homeList.addView(TextView(this).apply {
            text = "Ajouter un Mikhmon"; setTextColor(Color.GRAY); textSize = 13f
            setPadding(dp(4), dp(18), 0, dp(8))
        })
        homeList.addView(importButton("Importer un dossier") { pickFolder() },
            LinearLayout.LayoutParams(MATCH_PARENT, dp(52)).apply { bottomMargin = dp(10) })
        homeList.addView(importButton("Importer un fichier ZIP") { pickZip() },
            LinearLayout.LayoutParams(MATCH_PARENT, dp(52)))
    }

    private fun importButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f
        setTextColor(Color.WHITE); background = roundBg(green)
        setOnClickListener { action() }
    }

    // ---------------------------------------------------------------- Import

    private fun pickFolder() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_FOLDER)
        } catch (e: Exception) {
            alert("Impossible d'ouvrir le sélecteur de dossier sur ce téléphone. Utilisez l'import ZIP.")
        }
    }

    private fun pickZip() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed",
                "application/octet-stream"))
        }
        try { startActivityForResult(i, REQ_ZIP) } catch (e: Exception) { alert("Sélecteur de fichiers indisponible.") }
    }

    private fun askNameThenImport(uri: Uri, isFolder: Boolean) {
        val input = EditText(this).apply {
            setText(sites.defaultName(uri, isFolder)); setSelectAllOnFocus(true)
        }
        val box = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(input) }
        AlertDialog.Builder(this)
            .setTitle("Nom de ce Mikhmon")
            .setMessage("Par exemple : Mikhmon v6 ou Mikhmon v7")
            .setView(box)
            .setPositiveButton("Importer") { _, _ -> runImport(uri, isFolder, input.text.toString().trim()) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun runImport(uri: Uri, isFolder: Boolean, name: String) {
        showLoading("Import de « $name »…\nCela peut prendre une minute.")
        Thread {
            try {
                if (isFolder) sites.importFolder(uri, name) else sites.importZip(uri, name)
                ui.post { showLoading(null); showHome() }
            } catch (e: Exception) {
                ui.post { showLoading(null); alert("Échec de l'import.\n\n${e.message}") }
            }
        }.start()
    }

    private fun siteMenu(site: Site) {
        AlertDialog.Builder(this)
            .setTitle(site.name)
            .setItems(arrayOf("Renommer", "Supprimer")) { _, which ->
                if (which == 0) {
                    val input = EditText(this).apply { setText(site.name) }
                    val box = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(input) }
                    AlertDialog.Builder(this).setTitle("Renommer").setView(box)
                        .setPositiveButton("OK") { _, _ -> sites.rename(site, input.text.toString().trim()); showHome() }
                        .setNegativeButton("Annuler", null).show()
                } else {
                    AlertDialog.Builder(this).setTitle("Supprimer « ${site.name} » ?")
                        .setMessage("Ce Mikhmon et ses réglages (routeurs, modèles) seront effacés de l'application. " +
                            "Votre dossier d'origine n'est pas touché.")
                        .setPositiveButton("Supprimer") { _, _ ->
                            if (currentSite?.id == site.id) { server.stop(); currentSite = null }
                            sites.delete(site); showHome()
                        }
                        .setNegativeButton("Annuler", null).show()
                }
            }.show()
    }

    // ---------------------------------------------------------------- Ouverture

    private fun openSite(site: Site) {
        showLoading("Démarrage de « ${site.name} »…")
        Thread {
            try {
                val changed = currentSite?.id != site.id || !server.isRunning()
                server.start(sites.dirOf(site), site.id)
                ui.post {
                    currentSite = site
                    webTitle.text = "◀  ${site.name}"
                    if (changed || webView.url == null) {
                        webView.clearHistory()
                        webView.loadUrl("http://127.0.0.1:${server.port}/admin.php?id=login")
                    }
                    home.visibility = View.GONE
                    webPanel.visibility = View.VISIBLE
                    showLoading(null)
                }
            } catch (e: Exception) {
                ui.post { showLoading(null); alert(e.message ?: e.toString()) }
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        // Si Android a arrêté le serveur pendant que l'appli était en arrière-plan
        val site = currentSite
        if (site != null && webPanel.visibility == View.VISIBLE && !server.isRunning()) {
            showLoading("Redémarrage…")
            Thread {
                try {
                    server.start(sites.dirOf(site), site.id)
                    ui.post {
                        webView.loadUrl("http://127.0.0.1:${server.port}/admin.php?id=sessions")
                        showLoading(null)
                    }
                } catch (e: Exception) {
                    ui.post { showLoading(null); alert(e.message ?: e.toString()) }
                }
            }.start()
        }
    }

    private fun alert(msg: String) {
        if (isFinishing) return
        AlertDialog.Builder(this).setTitle("MIKRAFDJAF").setMessage(msg).setPositiveButton("OK", null).show()
    }

    // ---------------------------------------------------------------- Impression

    inner class PrintBridge {
        @JavascriptInterface
        fun print() { ui.post { doPrint() } }
    }

    private fun doPrint() {
        val now = System.currentTimeMillis()
        if (now - lastPrint < 1500) return
        lastPrint = now
        ui.postDelayed({
            try {
                val pm = getSystemService(PRINT_SERVICE) as PrintManager
                val name = "MIKRAFDJAF-" + (webView.title ?: "impression")
                pm.print(name, webView.createPrintDocumentAdapter(name), null)
            } catch (e: Exception) { }
        }, 600)
    }

    // ---------------------------------------------------------------- Résultats

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQ_UPLOAD -> {
                fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                fileCallback = null
            }
            REQ_FOLDER, REQ_ZIP -> {
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null) askNameThenImport(uri, requestCode == REQ_FOLDER)
            }
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            loading.visibility == View.VISIBLE -> return
            webPanel.visibility == View.VISIBLE && webView.canGoBack() -> webView.goBack()
            webPanel.visibility == View.VISIBLE -> showHome()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (isFinishing) server.stop()
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val REQ_UPLOAD = 41
        private const val REQ_FOLDER = 42
        private const val REQ_ZIP = 43
    }
}
