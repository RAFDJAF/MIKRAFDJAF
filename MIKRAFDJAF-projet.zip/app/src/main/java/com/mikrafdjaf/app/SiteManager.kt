package com.mikrafdjaf.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipInputStream

data class Site(val id: String, val name: String)

/** Gère les Mikhmon importés par l'utilisateur (ex. "Mikhmon v6", "Mikhmon v7"). */
class SiteManager(private val ctx: Context) {

    private val prefs = ctx.getSharedPreferences("sites", Context.MODE_PRIVATE)
    private val sitesDir = File(ctx.filesDir, "sites").apply { mkdirs() }

    fun list(): List<Site> {
        val arr = JSONArray(prefs.getString("list", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Site(o.getString("id"), o.getString("name"))
        }.filter { dirOf(it).isDirectory }
    }

    private fun save(list: List<Site>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name)) }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    fun dirOf(site: Site) = File(sitesDir, site.id)

    fun rename(site: Site, newName: String) {
        save(list().map { if (it.id == site.id) Site(it.id, newName.ifBlank { it.name }) else it })
    }

    fun delete(site: Site) {
        dirOf(site).deleteRecursively()
        File(ctx.filesDir, "sessions/${site.id}").deleteRecursively()
        save(list().filter { it.id != site.id })
    }

    /** Nom proposé par défaut (nom du fichier zip ou du dossier choisi). */
    fun defaultName(uri: Uri, isTree: Boolean): String {
        val raw = try {
            if (isTree) DocumentFile.fromTreeUri(ctx, uri)?.name
            else ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (e: Exception) { null }
        return (raw ?: "Mikhmon").removeSuffix(".zip").removeSuffix(".ZIP")
    }

    fun importZip(uri: Uri, name: String): Site {
        val tmp = newTmp()
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Fichier illisible")
        input.use { unzip(it, tmp) }
        return finish(tmp, name)
    }

    fun importFolder(treeUri: Uri, name: String): Site {
        val tmp = newTmp()
        val root = DocumentFile.fromTreeUri(ctx, treeUri) ?: throw IOException("Dossier illisible")
        copyTree(root, tmp)
        return finish(tmp, name)
    }

    private fun newTmp(): File =
        File(ctx.cacheDir, "import_${System.currentTimeMillis()}").apply { deleteRecursively(); mkdirs() }

    private fun unzip(input: InputStream, dest: File) {
        val root = dest.canonicalPath + File.separator
        ZipInputStream(input.buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val out = File(dest, entry.name)
                if (!out.canonicalPath.startsWith(root)) throw IOException("Archive invalide")
                if (entry.isDirectory) out.mkdirs()
                else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zip.copyTo(it) }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
    }

    private fun copyTree(doc: DocumentFile, dest: File) {
        dest.mkdirs()
        for (child in doc.listFiles()) {
            val n = child.name ?: continue
            if (n.contains('/') || n == "." || n == "..") continue
            val out = File(dest, n)
            if (child.isDirectory) copyTree(child, out)
            else ctx.contentResolver.openInputStream(child.uri)?.use { i ->
                FileOutputStream(out).use { i.copyTo(it) }
            }
        }
    }

    /** Cherche le dossier qui contient admin.php (Mikhmon peut être dans un sous-dossier). */
    private fun findRoot(dir: File, depth: Int = 0): File? {
        if (File(dir, "admin.php").isFile) return dir
        if (depth >= 4) return null
        dir.listFiles()?.filter { it.isDirectory }?.forEach { sub ->
            findRoot(sub, depth + 1)?.let { return it }
        }
        return null
    }

    private fun finish(tmp: File, name: String): Site {
        val root = findRoot(tmp)
        if (root == null) {
            tmp.deleteRecursively()
            throw IOException("Mikhmon introuvable : aucun fichier admin.php dans ce que vous avez choisi.")
        }
        val id = "s" + System.currentTimeMillis()
        val dest = File(sitesDir, id)
        if (!root.renameTo(dest)) {
            root.copyRecursively(dest, overwrite = true)
        }
        tmp.deleteRecursively()
        val site = Site(id, name.ifBlank { "Mikhmon" })
        save(list() + site)
        return site
    }
}
