package com.mikrafdjaf.app

import android.content.Context
import android.provider.Settings
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/**
 * Licence par téléphone.
 * - Chaque téléphone a un « code téléphone » (dérivé de son identifiant Android).
 * - Le vendeur signe ce code avec sa clé privée (générateur de licences) et obtient la « clé de licence ».
 * - L'application vérifie la signature avec la clé publique ci-dessous : impossible de fabriquer
 *   une clé valide sans la clé privée, qui n'est PAS dans l'application.
 */
object License {

    // Clé publique ECDSA P-256 du vendeur (la clé privée reste dans le générateur de licences)
    private const val PUBLIC_KEY_B64 =
        "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAECvZTN3/R//L96Xyq52NEcCx2sUFMBCtDu7hhPDIP96kW49RKdAAVwTGXry2QkJMji0mj0HCpsWd6rBe0/M/efg=="

    private const val MESSAGE_PREFIX = "MIKRAFDJAF-L1:"
    private const val ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ" // base32 Crockford

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("licence", Context.MODE_PRIVATE)

    /** Code à envoyer au vendeur, ex. 7K2QF-M9X4D */
    fun deviceCode(ctx: Context): String {
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "inconnu"
        val h = MessageDigest.getInstance("SHA-256").digest("MIKRAFDJAF:$id".toByteArray())
        var bits = 0L
        for (i in 0 until 7) bits = (bits shl 8) or (h[i].toLong() and 0xFF)
        val sb = StringBuilder()
        for (i in 0 until 10) sb.append(ALPHABET[((bits shr (51 - 5 * i)) and 31).toInt()])
        return sb.substring(0, 5) + "-" + sb.substring(5, 10)
    }

    /** Majuscules, sans tirets ni espaces ; O→0, I/L→1 (évite les erreurs de saisie). */
    fun normalizeCode(code: String): String =
        code.uppercase().filter { it.isLetterOrDigit() }
            .replace('O', '0').replace('I', '1').replace('L', '1')

    fun verify(code: String, key: String): Boolean = try {
        val clean = key.filter { it.isLetterOrDigit() || it == '-' || it == '_' }
        val raw = android.util.Base64.decode(clean, android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING or android.util.Base64.NO_WRAP)
        if (raw.size != 64) false else {
            val pub = KeyFactory.getInstance("EC").generatePublic(
                X509EncodedKeySpec(android.util.Base64.decode(PUBLIC_KEY_B64, android.util.Base64.DEFAULT)))
            val s = Signature.getInstance("SHA256withECDSA")
            s.initVerify(pub)
            s.update((MESSAGE_PREFIX + normalizeCode(code)).toByteArray())
            s.verify(rawToDer(raw))
        }
    } catch (e: Exception) { false }

    fun isActivated(ctx: Context): Boolean {
        val key = prefs(ctx).getString("cle", null) ?: return false
        return verify(deviceCode(ctx), key)
    }

    /** Enregistre la clé si elle est valide pour ce téléphone. */
    fun activate(ctx: Context, key: String): Boolean {
        val ok = verify(deviceCode(ctx), key)
        if (ok) prefs(ctx).edit().putString("cle", key.trim()).apply()
        return ok
    }

    /** Signature brute r||s (64 octets) -> format DER attendu par Java. */
    private fun rawToDer(raw: ByteArray): ByteArray {
        fun intDer(b: ByteArray): ByteArray {
            var i = 0
            while (i < b.size - 1 && b[i].toInt() == 0) i++
            var v = b.copyOfRange(i, b.size)
            if (v[0].toInt() and 0x80 != 0) v = byteArrayOf(0) + v
            return byteArrayOf(0x02, v.size.toByte()) + v
        }
        val r = intDer(raw.copyOfRange(0, 32))
        val s = intDer(raw.copyOfRange(32, 64))
        val body = r + s
        return byteArrayOf(0x30, body.size.toByte()) + body
    }
}
