package com.mikrafdjaf.app

import android.content.Context
import java.io.File
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Petit serveur web local (comme KSWEB, en plus simple) :
 * lance le binaire PHP intégré (php -S 127.0.0.1:PORT) sur le dossier du Mikhmon choisi.
 */
class PhpServer(private val ctx: Context) {

    private var process: Process? = null
    var port: Int = 0
        private set
    var docRoot: File? = null
        private set

    private val logFile get() = File(ctx.filesDir, "php_server.log")
    private val phpBin get() = File(ctx.applicationInfo.nativeLibraryDir, "libphp.so")

    private fun writePhpIni(siteId: String): File {
        // Sessions séparées pour chaque Mikhmon (v6 et v7 ne se mélangent pas)
        val sessions = File(ctx.filesDir, "sessions/$siteId").apply { mkdirs() }
        val tmp = File(ctx.cacheDir, "tmp").apply { mkdirs() }
        val ini = File(ctx.filesDir, "php.ini")
        ini.writeText(
            """
            display_errors = Off
            error_reporting = E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING
            log_errors = On
            error_log = "${File(ctx.filesDir, "php_errors.log").absolutePath}"
            memory_limit = 256M
            max_execution_time = 120
            default_socket_timeout = 15
            upload_max_filesize = 16M
            post_max_size = 16M
            date.timezone = Africa/Porto-Novo
            session.save_path = "${sessions.absolutePath}"
            session.gc_maxlifetime = 86400
            sys_temp_dir = "${tmp.absolutePath}"
            upload_tmp_dir = "${tmp.absolutePath}"
            opcache.enable = 0
            opcache.enable_cli = 0
            """.trimIndent()
        )
        return ini
    }

    private fun findFreePort(): Int {
        for (p in 18080..18089) {
            try {
                ServerSocket().use { it.bind(InetSocketAddress("127.0.0.1", p)) }
                return p
            } catch (e: Exception) { }
        }
        ServerSocket(0).use { return it.localPort }
    }

    fun isRunning(): Boolean {
        val p = process ?: return false
        return try { p.exitValue(); false } catch (e: IllegalThreadStateException) { true }
    }

    /** Démarre PHP sur le dossier donné et attend qu'il réponde. */
    fun start(root: File, siteId: String) {
        if (isRunning() && docRoot == root) return
        stop()
        if (!phpBin.exists()) {
            throw IllegalStateException(
                "Le moteur PHP est introuvable.\nCe téléphone (processeur 32 bits) n'est peut-être pas compatible."
            )
        }
        val ini = writePhpIni(siteId)
        port = findFreePort()

        val pb = ProcessBuilder(
            phpBin.absolutePath, "-c", ini.absolutePath,
            "-S", "127.0.0.1:$port", "-t", root.absolutePath
        )
        pb.directory(root)
        pb.redirectErrorStream(true)
        pb.environment().apply {
            put("PHP_CLI_SERVER_WORKERS", "4")
            put("TMPDIR", File(ctx.cacheDir, "tmp").absolutePath)
            put("HOME", ctx.filesDir.absolutePath)
        }
        val proc = pb.start()
        process = proc
        docRoot = root

        Thread {
            try {
                logFile.outputStream().use { out -> proc.inputStream.copyTo(out) }
            } catch (e: Exception) { }
        }.apply { isDaemon = true }.start()

        val deadline = System.currentTimeMillis() + 15_000
        while (System.currentTimeMillis() < deadline) {
            if (!isRunning()) break
            try {
                Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 300) }
                return
            } catch (e: Exception) {
                Thread.sleep(200)
            }
        }
        stop()
        val log = try { logFile.readText().takeLast(1500) } catch (e: Exception) { "" }
        throw IllegalStateException("Le serveur PHP n'a pas démarré.\n$log")
    }

    fun stop() {
        process?.destroy()
        process = null
        docRoot = null
        killStrays()
    }

    /** Arrête aussi les processus PHP secondaires (workers) restés en route. */
    fun killStrays() {
        val bin = phpBin.absolutePath
        File("/proc").listFiles()?.forEach { dir ->
            val pid = dir.name.toIntOrNull() ?: return@forEach
            if (pid == android.os.Process.myPid()) return@forEach
            try {
                val cmd = File(dir, "cmdline").readText()
                if (cmd.startsWith(bin)) {
                    android.os.Process.sendSignal(pid, android.os.Process.SIGNAL_KILL)
                }
            } catch (e: Exception) { }
        }
    }
}
