package com.mikrafdjaf.app

import android.content.Context
import java.io.File
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Petit serveur web local (comme KSWEB, en plus simple) :
 * lance le binaire PHP intégré (php -S 127.0.0.1:PORT) sur le dossier du Mikhmon choisi.
 */
class PhpServer(private val ctx: Context) {

    private var process: Process? = null
    var port: Int = 0
        private set
    var docRoot: File? = null
        private set

    private val logFile get() = File(ctx.filesDir, "php_server.log")
    private val phpBin get() = File(ctx.applicationInfo.nativeLibraryDir, "libphp.so")

    private fun writePhpIni(siteId: String): File {
        // Sessions séparées pour chaque Mikhmon (v6 et v7 ne se mélangent pas)
        val sessions = File(ctx.filesDir, "sessions/$siteId").apply { mkdirs() }
        val tmp = File(ctx.cacheDir, "tmp").apply { mkdirs() }
        val ini = File(ctx.filesDir, "php.ini")
        ini.writeText(
            """
            display_errors = Off
            error_reporting = E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING
            log_errors = On
            error_log = "${File(ctx.filesDir, "php_errors.log").absolutePath}"
            memory_limit = 256M
            max_execution_time = 120
            default_socket_timeout = 15
            upload_max_filesize = 16M
            post_max_size = 16M
            date.timezone = Africa/Porto-Novo
            session.save_path = "${sessions.absolutePath}"
            session.gc_maxlifetime = 86400
            sys_temp_dir = "${tmp.absolutePath}"
            upload_tmp_dir = "${tmp.absolutePath}"
            opcache.enable = 0
            opcache.enable_cli = 0
            """.trimIndent()
        )
        return ini
    }

    private fun findFreePort(): Int {
        for (p in 18080..18089) {
            try {
                ServerSocket().use { it.bind(InetSocketAddress("127.0.0.1", p)) }
                return p
            } catch (e: Exception) { }
        }
        ServerSocket(0).use { return it.localPort }
    }

    @Volatile var lastExit: Int? = null

    fun describeExit(c: Int): String {
        if (c <= 128) return "code de sortie $c"
        val sig = c - 128
        val name = mapOf(4 to "SIGILL", 6 to "SIGABRT", 7 to "SIGBUS", 9 to "SIGKILL (arrêté par Android)",
            11 to "SIGSEGV", 13 to "SIGPIPE", 15 to "SIGTERM", 31 to "SIGSYS (fonction bloquée par Android)")[sig] ?: "signal"
        return "signal $sig $name"
    }

    fun logTail(n: Int): String = try { logFile.readText().takeLast(n) } catch (e: Exception) { "" }

    /** Texte de diagnostic affiché quand une page ne se charge pas. */
    fun diagnostic(): String {
        val etat = if (isRunning()) "actif (port $port)" else "arrêté" + (lastExit?.let { " – " + describeExit(it) } ?: "")
        val errs = try { File(ctx.filesDir, "php_errors.log").readText().takeLast(600) } catch (e: Exception) { "" }
        return "Serveur PHP : $etat\nAndroid ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}), " +
            "${android.os.Build.SUPPORTED_ABIS.joinToString()}\n\n--- Journal ---\n" + logTail(1500) +
            (if (errs.isNotBlank()) "\n--- Erreurs PHP ---\n$errs" else "")
    }

    fun isRunning(): Boolean {
        val p = process ?: return false
        return try { p.exitValue(); false } catch (e: IllegalThreadStateException) { true }
    }

    /** Démarre PHP sur le dossier donné et attend qu'il réponde. */
    fun start(root: File, siteId: String) {
        if (isRunning() && docRoot == root) return
        stop()
        if (!phpBin.exists()) {
            throw IllegalStateException(
                "Le moteur PHP est introuvable.\nCe téléphone (processeur 32 bits) n'est peut-être pas compatible."
            )
        }
        val ini = writePhpIni(siteId)
        port = findFreePort()

        val pb = ProcessBuilder(
            phpBin.absolutePath, "-c", ini.absolutePath,
            "-S", "127.0.0.1:$port", "-t", root.absolutePath
        )
        pb.directory(root)
        pb.redirectErrorStream(true)
        pb.environment().apply {
            put("TMPDIR", File(ctx.cacheDir, "tmp").absolutePath)
            put("HOME", ctx.filesDir.absolutePath)
        }
        // Journal : on garde les derniers démarrages (utile pour le diagnostic)
        try { if (logFile.length() > 200_000) logFile.writeText(logFile.readText().takeLast(50_000)) } catch (e: Exception) { }
        try { logFile.appendText("\n=== Démarrage ${java.util.Date()} port $port dossier ${root.name} ===\n") } catch (e: Exception) { }
        // La sortie de PHP va directement dans le fichier journal (pas de tuyau qui pourrait se fermer)
        val direct = android.os.Build.VERSION.SDK_INT >= 26
        if (android.os.Build.VERSION.SDK_INT >= 26) pb.redirectOutput(ProcessBuilder.Redirect.appendTo(logFile))
        val proc = pb.start()
        process = proc
        docRoot = root
        lastExit = null

        if (!direct) {
            Thread {
                try {
                    java.io.FileOutputStream(logFile, true).use { out -> proc.inputStream.copyTo(out) }
                } catch (e: Exception) { }
            }.apply { isDaemon = true }.start()
        }
        // Surveille l'arrêt du serveur pour pouvoir l'expliquer
        Thread {
            try {
                val c = proc.waitFor()
                if (process === proc) lastExit = c
                logFile.appendText("\n=== PHP arrêté : ${describeExit(c)} ===\n")
            } catch (e: Exception) { }
        }.apply { isDaemon = true }.start()

        val deadline = System.currentTimeMillis() + 20_000
        var lastErr = ""
        while (System.currentTimeMillis() < deadline) {
            try {
                Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 500) }
                return
            } catch (e: Exception) {
                lastErr = e.toString()
            }
            if (!isRunning()) break
            Thread.sleep(250)
        }
        val code = try { describeExit(proc.exitValue()) } catch (e: Exception) { "en cours" }
        stop()
        throw IllegalStateException("Le serveur PHP n'a pas démarré.\n[$code | $lastErr]\n" + logTail(1200))
    }

    fun stop() {
        process?.destroy()
        process = null
        docRoot = null
        killStrays()
    }

    /** Arrête aussi les processus PHP secondaires (workers) restés en route. */
    fun killStrays() {
        val bin = phpBin.absolutePath
        File("/proc").listFiles()?.forEach { dir ->
            val pid = dir.name.toIntOrNull() ?: return@forEach
            if (pid == android.os.Process.myPid()) return@forEach
            try {
                val cmd = File(dir, "cmdline").readText()
                if (cmd.startsWith(bin)) {
                    android.os.Process.sendSignal(pid, android.os.Process.SIGNAL_KILL)
                }
            } catch (e: Exception) { }
        }
    }
}
