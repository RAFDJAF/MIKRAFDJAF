# MIKRAFDJAF

Application Android (7.0 et plus, téléphones 64 bits) qui fait tourner
vos propres Mikhmon directement sur le téléphone, sans KSWEB.

- Serveur PHP intégré, démarré automatiquement à l'ouverture
- Au premier lancement : importez votre dossier Mikhmon (ou un ZIP). Plusieurs versions possibles (ex. v6 et v7)
- Touchez le Mikhmon voulu pour l'ouvrir ; appui long pour renommer ou supprimer
- Impression des tickets et rapports via le service d'impression d'Android
- Les réglages de chaque Mikhmon importé sont conservés lors des mises à jour

Limites connues :
- Téléphones 32 bits uniquement : non compatibles
- Dans Mikhmon, indiquez l'adresse IP du routeur (pas un nom de domaine)

Fabrication : automatique via GitHub Actions (fichier .github/workflows/build.yml).
L'APK est publié dans l'onglet « Releases » du dépôt.
